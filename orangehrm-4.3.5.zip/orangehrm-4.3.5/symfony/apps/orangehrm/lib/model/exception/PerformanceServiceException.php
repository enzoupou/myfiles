<?php
class PerformanceServiceException extends ServiceException
{
	
}