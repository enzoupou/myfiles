$(document).ready(function () {
    $("#MP_link").click(function () {
        window.location.replace(marketplaceURL);
    });

    $("#Subscriber_link").click(function () {
        window.location.replace(SubscriberURL);
    });
});
