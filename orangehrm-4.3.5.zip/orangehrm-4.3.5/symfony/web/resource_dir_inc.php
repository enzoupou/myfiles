<?php 
sfConfig::set('sf_web_css_dir_name','webres_5e7b15c4882d04.47780062/css');
sfConfig::set('sf_web_js_dir_name','webres_5e7b15c4882d04.47780062/js');
sfConfig::set('sf_web_images_dir_name','webres_5e7b15c4882d04.47780062/images');
sfConfig::set('ohrm_resource_dir', 'webres_5e7b15c4882d04.47780062');