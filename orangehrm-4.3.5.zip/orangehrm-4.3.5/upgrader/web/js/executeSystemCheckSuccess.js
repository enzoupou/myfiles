$(document).ready(function(){
    
    $('#recheckButton').click(function () {
        window.location.reload();
    });
});