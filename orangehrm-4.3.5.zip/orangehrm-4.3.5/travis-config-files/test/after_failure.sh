cd tests/_output/
ls | xargs cat
