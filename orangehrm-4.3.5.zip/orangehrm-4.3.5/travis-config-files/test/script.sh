php codecept.phar run acceptance
symfony/lib/vendor/bin/phpunit --coverage-clover build/logs/clover.xml